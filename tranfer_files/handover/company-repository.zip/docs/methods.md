# Methods

Transferred from the [versioned source methods](https://github.com/CathalD/Carbon_Data_SOD/blob/6b125781e40267867399372d65b2fd72fc30670d/Comparison/report/methods.qmd). These methods describe the existing comparison results. Chosen-area totals and other unfinished summary panels require the additional work identified in the [summaries scaffold](summaries.md).

Pair definitions are retained in the [analysis snapshot](../analysis/source_snapshot/Comparison/data/derived/pairs.json).

## Analytical design

| | |
|---|---|
| **Question** | Where do Canadian carbon products agree or disagree when compared like with like, and how do soil maps compare with field profiles? The McMaster/WWF maps (Sothe et al. 2022) are compared first. |
| **Estimand** | Per-pixel differences (A − B) on each pair's coarser native grid, summarised as mean difference, RMSD, Pearson r and share within ±25%, nationally and by terrestrial ecozone. At profiles: map value at the containing pixel vs the thickness-weighted observed value for the same interval and depth datum. |
| **Data roles** | Maps are products being compared; none is treated as truth. Profiles are observations, but not independent validation where they trained a map. Ecozones are reporting units only. |
| **Method** | Documented unit conversion, mean aggregation of the finer product to the coarser grid, differencing and descriptive statistics. Two derivations, both labelled: a SoilGrids 0–100 cm stock from its carbon density, and SCANFI carbon from biomass × 0.5. No modelling, gap-filling or bias correction. |
| **Not part of this analysis** | Deriving stocks from concentration × bulk density for Geng; deduplicating profiles across datasets; forest plot comparisons (no plots ingested yet); propagating map uncertainty. |

## Rules for pairing products

1. **Same quantity, same depth or pool.** Products are paired only when both report the same quantity for the same depth interval, or the same pool and year. Everything else is listed, with the reason, under "Products not compared". Two McMaster/WWF pairs are labelled exceptions:
    - **Sothe vs SoilGrids 0–100 cm.** SoilGrids has no released 0–100 cm stock, so one is derived from its carbon density.
    - **McMaster/WWF forest carbon vs SCANFI.** The pools differ: McMaster includes belowground and dead carbon.
2. **Depth datum, not just depth label.** Each pair records its depth datum and whether that is matched, still to verify, or may differ. Fixed-depth mineral-soil stocks, organic-inclusive stocks and full-column peat stocks are kept in separate categories and never ranked together.
3. **Coarser grid per pair.** Each pair is compared on the coarser of its two native grids. The finer product is mean-aggregated (Earth Engine `reduceResolution`, mean of contributing pixels) to that grid. Nothing is upsampled.
4. **Documented units only.** Values are converted with the providers' documented factors to one unit per quantity.
5. **Missing data stay missing.** PEATGRIDS stores missing values as NaN in unmasked pixels outside mapped peatland. Its non-negative variables are masked with `updateMask(image.gte(0))` at the product definition, before any sampling, aggregation or display. Recorded zeros (for example NCSCDv2 rock and ice units) are kept as values.



## Sampling and maps

Statistics come from **30,000 random points**, uniform in area. They are drawn in Canada Albers equal-area (ESRI:102001) within the terrestrial ecozones, seed 42. The peat pairs use **1,500 points** in the Hudson Plain ecozone (seed 43). At each point, both products of a pair are read on the pair's comparison grid.

**Each band is sampled independently** (`reduceRegions` with a per-band `first` reducer). A point missing one depth, one variable or one product is dropped only for the pair that needs it. Earth Engine's `sampleRegions` would instead drop a point from every band when any band is masked. For aboveground biomass and forest carbon, points where both products are zero are dropped, so shared non-forest does not inflate agreement.

**Maps are drawn from the same samples.** Each hexagon shows the mean of the sampled comparison-grid pixels inside it, for A, B and A − B. Hexagons are 100 km across nationally and 40 km in the Hudson Plain, and only points where both products have data are used. The aggregation is therefore explicit, and the maps use the same points, units and eligibility rules as the tables.

## Profiles

- **Depth matching:** layers are combined into each map interval by thickness-weighted mean, only where they cover the whole interval with no gaps or overlaps. No extrapolation and no splines.
- **Two depth datums, kept separate:**
    - *Mineral surface*: organic surface layers removed (WoSIS `organic_surface`; NPDB horizons above 0 cm, i.e. LFH) and the first remaining layer set to 0 cm. WoSIS and NPDB only. Used with Geng and SoilGrids, because SoilGrids removes overlying organic layers.
    - *Profile surface*: depth from the top of the profile, organic layers included; NPDB is shifted so its profile top is 0. Used with the organic-inclusive stock maps (Sothe, NCSCDv2) and for the dataset inventory.
- **Peat thickness:** the NRCan peat cores' recorded organic depth (`ORG_DEPTH`) is compared with modelled peat thickness.
- **Stocks at 0–30 and 0–100 cm:** sums of each dataset's own layer stock values times the fraction of each layer inside the interval. No bulk density is gap-filled.
- **Exclusions:**
    - Riley bulk density: units are unverified, so it is kept in the inventory but excluded from every quantitative result.
    - Janousek: profiles whose recorded layer thickness disagrees with their boundaries by more than 0.01 cm are excluded from depth integration.
- **Map values:** each profile takes the value of the map pixel that contains it, at the map's native grid, with each band read independently.
- **Units:** organic carbon in g/kg (WoSIS stored in g/kg; the others in %, ×10); bulk density in g/cm³; stocks in kg C/m². Layer stocks reproduce `C(g/kg) × BD × thickness / 100` for WoSIS and `C(%) × BD × thickness / 10` for Janousek. NRCan provider stocks are close to, but not identical with, the corresponding expression, so the provider values are used as given.

## Unit conversions

| Product | Stored | Converted to | Factor | Source |
|---|---|---|---|---|
| SoilGrids `soc` | dg/kg | g/kg | ÷ 10 | ISRIC SoilGrids FAQ |
| SoilGrids `bdod` | cg/cm³ | g/cm³ | ÷ 100 | ISRIC SoilGrids FAQ |
| SoilGrids `ocs` | t/ha | kg C/m² | ÷ 10 | ISRIC SoilGrids FAQ |
| SoilGrids `ocd` → 0–100 cm stock (derived) | hg/m³ | kg C/m² | ÷ 10, × interval thickness (m), summed over 0–5 … 60–100 cm | ISRIC SoilGrids FAQ; derivation here |
| Geng SOC | % | g/kg | × 10 | Provider (CanSIS); imported encoding still pending |
| Geng BD | g/cm³ | g/cm³ | 1 | Provider (CanSIS); imported encoding still pending |
| NCSCDv2 SOCC30 / SOCC100 | hg C/m² | kg C/m² | ÷ 10 | Bolin Centre NCSCD raster documentation |
| Sothe stock (hosted v2.0) | kg C/m² | kg C/m² | 1 | Sothe et al. 2022; 0–1 m (maintainer-confirmed 2026-10-16) |
| PEATGRIDS carbon / thickness | Mg C/m² / cm | kg C/m² / cm | × 1000 / 1 | PEATGRIDS v2.1 metadata (full modelled peat column) |
| Li et al. carbon / depth | kg C/m² / cm | same | 1 | Study units; import encoding unverified |
| McMaster/WWF forest carbon | kg C/m² | kg C/m² | 1 | Sothe et al. 2022; above + below + dead pools |
| SCANFI biomass → carbon | t/ha | kg C/m² | × 0.5 carbon fraction × 0.1 | Fraction chosen for this report; IPCC default 0.47 would lower SCANFI carbon by 6% |
| SCANFI biomass / ESA CCI AGB | t/ha / Mg/ha | Mg/ha | 1 | Provider documentation; biomass is not carbon |

## Ecozones

Canada's 15 terrestrial ecozones from the AAFC National Ecological Framework (`ecozone_shp.zip`, Open Government Licence – Canada), stored in `analysis/source_snapshot/Comparison/data/ecozones/`.

## Limitations

- **Agreement is not accuracy.** Two maps can agree because they share training data or covariates.
- **Support mismatch.** A soil core or inventory plot covers a few square metres; the pixels are 30 m to about 1.3 km.
- **Temporal mismatch.** Profiles span 1939–2017; maps represent their own reference periods.
- **Depth datums.** Geng's and NCSCDv2's organic-layer treatment is documented only partly; pairs that depend on it are labelled rather than assumed equivalent. SoilGrids excludes overlying organic layers.
- **Imported encodings.** The imported encodings of Geng and Li are tracked in the repository QC register. Distributions of values cannot settle these; source metadata and file identity must.
- **Uncertainty layers** use different statistics (SD, quantile intervals, model disagreement) and are not compared.

## Verification status

See the [QC register](../data/downloads/QC_register.csv), [soil-map QC notes](soil_quality_checks.md) and pair definitions for source-specific verification and unresolved encodings. Retain those qualifications when comparing results.

## Reproduce

The [analysis guide](../analysis/README.md) explains how to rebuild the example figures from bundled prepared inputs and where to find the preserved comparison workflow. The original report sources are under `analysis/source_snapshot/Comparison/`. Full analysis refreshes also require external preparation inputs and Earth Engine access; the company GitHub Pages deployment is still to be configured.
